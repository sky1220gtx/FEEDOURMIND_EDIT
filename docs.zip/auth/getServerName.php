<?php
$ServerName = $_SERVER['SERVER_NAME'];
// echo $ServerName;
?>